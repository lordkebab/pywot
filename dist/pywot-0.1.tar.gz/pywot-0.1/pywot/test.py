from api import API
from tankopedia import Tankopedia
from player import Player
from rating import Rating
import json

app = API('69e26edf6780d2e133ad4016ef97753a')
t = Tankopedia(app.app_id)
# print t.list_of_vehicles()

#p = Player(app.app_id)

#r = Rating(app.app_id)

#print r.rating_types()

#print p.player_achievements(account_id=p.get_account_id(nickname='lulz_man'))


	
#print p.search_players(search='lulz_man')

#print p.get_account_id(nickname='lulz_man')

#print json.dumps(t.vehicle_details(tank_id='18689'))
#tank_id = '18689'
kv1s = t.vehicle_details(language='ko', tank_id=['18689','33'], fields=['tank_id', 'nation', 'speed_limit', 'engines.module_id'])

print kv1s

#kv1s_mod0 = json.dumps(kv1s['data'][tank_id]['chassis'], indent=4)

#print kv1s_mod0

#kv1s_chassis = t.suspensions(module_id=kv1s_mod0)
#print t.suspensions(module_id=10002)

#print kv1s_chassis

# print t.guns(module_id=6916)